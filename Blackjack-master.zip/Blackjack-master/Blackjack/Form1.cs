﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Blackjack
{
    public partial class Form1 : Form
    {
        // Changing the value of all Face Cards to 10 and the Ace to 11

        List<Card> playerCardList = new List<Card>()
        {
            new Card() { Value  = 0, Name = "null", Image = "null" }
        };

        List<Card> dealerCardList = new List<Card>()
        {
            new Card() { Value  = 0, Name = "null", Image = "null" }
        };

        int playerCardSum = 0;
        int dealerCardSum = 0;
        Random random = new Random();
        List<int> usedCards = new List<int>();
        List<PictureBox> dealerBox = new List<PictureBox>();
        List<PictureBox> playerBox = new List<PictureBox>();

        // Creating the Card Deck and assigning Images to each card.
        #region New Deck

        List<Card> deck = new List<Card>()
            {
                #region Spades

                new Card() { Value  = 2, Name = "Two Spades", Image = "2S.png" },
                new Card() { Value = 3, Name = "Three Spades", Image = "3S.png"},
                new Card() { Value = 4, Name =  "Four Spades", Image = "4S.png"},
                new Card() { Value = 5, Name = "Five Spades", Image = "5S.png" },
                new Card() { Value = 6, Name = "Six Spades", Image = "6S.png" },
                new Card() { Value = 7, Name = "Seven Spades", Image = "7S.png" },
                new Card() { Value = 8, Name = "Eight Spades", Image = "8S.png" },
                new Card() { Value = 9, Name = "Nine Spades", Image = "9S.png" },
                new Card() { Value = 10, Name = "Ten Spades", Image = "10S.png" },
                new Card() { Value = 10, Name = "Jack Spades", Image = "JS.png" },
                new Card() { Value = 10, Name = "Queen Spades", Image = "QS.png" },
                new Card(){ Value = 10, Name = "King Spades", Image = "KS.png" },
                new Card(){ Value = 11, Name = "Ace Spades", Image = "AS.png" },

                #endregion

                #region Diamonds

                new Card() { Value  = 2, Name = "Two Diamonds", Image = "2D.png" },
                new Card() { Value = 3, Name = "Three Diamonds", Image = "3D.png" },
                new Card() { Value = 4, Name =  "Four Diamonds", Image = "4D.png"},
                new Card() { Value = 5, Name = "Five Diamonds", Image = "5D.png" },
                new Card() { Value = 6, Name = "Six Diamonds", Image = "6D.png" },
                new Card(){ Value = 7, Name = "Seven Diamonds", Image = "7D.png" },
                new Card() { Value = 8, Name = "Eight Diamonds", Image = "8D.png" },
                new Card() { Value = 9, Name = "Nine Diamonds", Image = "9D.png" },
                new Card() { Value = 10, Name = "Ten Diamonds", Image = "10D.png" },
                new Card() { Value = 10, Name = "Jack Diamonds", Image = "JD.png" },
                new Card() { Value = 10, Name = "Queen Diamonds", Image = "QD.png" },
                new Card(){ Value = 10, Name = "King Diamonds", Image = "KD.png" },
                new Card(){ Value = 11, Name = "Ace Diamonds", Image = "AD.png" },

                #endregion

                #region Clubs

                new Card() { Value  = 2, Name = "Two Clubs", Image = "2C.png" },
                new Card() { Value = 3, Name = "Three Clubs", Image = "3C.png" },
                new Card() { Value = 4, Name =  "Four Clubs", Image = "4C.png"},
                new Card() { Value = 5, Name = "Five Clubs", Image = "5C.png" },
                new Card() { Value = 6, Name = "Six Clubs", Image = "6C.png" },
                new Card(){ Value = 7, Name = "Seven Clubs", Image = "7C.png" },
                new Card() { Value = 8, Name = "Eight Clubs", Image = "8C.png" },
                new Card() { Value = 9, Name = "Nine Clubs", Image= "9C.png" },
                new Card() { Value = 10, Name = "Ten Clubs", Image = "10C.png" },
                new Card() { Value = 10, Name = "Jack Clubs", Image = "JC.png" },
                new Card() { Value = 10, Name = "Queen Clubs", Image = "QC.png" },
                new Card(){ Value = 10, Name = "King Clubs", Image = "KC.png" },
                new Card(){ Value = 11, Name = "Ace Clubs", Image = "AC.png" },

                #endregion

                #region Hearts

                new Card() { Value  = 2, Name = "Two Hearts", Image = "2H.png" },
                new Card() { Value = 3, Name = "Three Hearts", Image = "3H.png" },
                new Card() { Value = 4, Name =  "Four Hearts", Image = "4H.png"},
                new Card() { Value = 5, Name = "Five Hearts", Image = "5H.png" },
                new Card() { Value = 6, Name = "Six Hearts", Image = "6H.png" },
                new Card(){ Value = 7, Name = "Seven Hearts", Image = "7H.png" },
                new Card() { Value = 8, Name = "Eight Hearts", Image = "8H.png" },
                new Card() { Value = 9, Name = "Nine Hearts", Image = "9H.png" },
                new Card() { Value = 10, Name = "Ten Hearts", Image = "10H.png" },
                new Card() { Value = 10, Name = "Jack Hearts", Image = "JH.png" },
                new Card() { Value = 10, Name = "Queen Hearts", Image = "QH.png" },
                new Card(){ Value = 10, Name = "King Hearts", Image = "KH.png" },
                new Card(){ Value = 11, Name = "Ace Hearts", Image = "AH.png" }

                #endregion
            };

        #endregion
        // Initialize the Form
        public Form1()
        {
            InitializeComponent();
        }

        // Reset the Game
        private void Form1_Load(object sender, EventArgs e)
        {
            resetGame();
        }

        //start the game
         private void startButton_Click(object sender, EventArgs e)
        {
           // if the player has already started the game and attempts to start the game with 0 cards, then alert them that the game has already started.
            if (playerCardSum > 0)
            {
                    resultLabel.Text = String.Format
                    ("The Game Has Already Begun!");
            }

            else
            // Otherwise state that the players Sum is 0 and the Dealer sum is 0 
            {
                playerCardSum = 0;
                dealerCardSum = 0;

                // Player initiation. The player will select a random card from the deck then add that random card to their hand.
                #region Initiate Player
                int randomCard1 = selectRandomCard();
                Card card1 = deck[randomCard1];
                usedCards.Add(randomCard1);
                int randomCard2 = selectRandomCard();

                // That random card will then be stored so as not to be used in the deck
                while (usedCards.Contains(randomCard2))
                {
                    randomCard2 = selectRandomCard();
                }
                randomCard2 = 1 * randomCard2;
                
                Card card2 = deck[randomCard2];
                usedCards.Add(randomCard2);

                playerCardList.Add(card1);
                playerCardList.Add(card2);
                
                pictureBox1.ImageLocation = card1.Image;
                pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
                
                pictureBox2.ImageLocation = card2.Image;
                pictureBox2.SizeMode = PictureBoxSizeMode.AutoSize;
                #endregion

                // The Dealer Initiation
                #region Initiate Dealer

                int randomCard3 = selectRandomCard();
                while (usedCards.Contains(randomCard3))
                {
                    randomCard3 = selectRandomCard();
                }
                randomCard3 = 1 * randomCard3;
                Card card3 = deck[randomCard3];
                usedCards.Add(randomCard3);

                dealerCardList.Add(card3);

                pictureBox4.ImageLocation = card3.Image;
                pictureBox4.SizeMode = PictureBoxSizeMode.AutoSize;

                #endregion

                sumPlayerCards();

                //This calculates the Sum of each of the cards to determine whether or not the players current hand beats the dealers 21 or not.

                if (playerCardSum == 21)
                {
                    resultLabel.Text = String.Format
                        ("The sum of your cards is: {0}, you win!", playerCardSum);
                    MessageBox.Show("You win!", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    resetGame();
                }


            }
        }

        // Select more random cards for the next deck
        private int selectRandomCard()
        {
            int randomCard;
            randomCard = random.Next(0, deck.Count);
            return randomCard;
        }

        // The sum of the Players Cards.
        private void sumPlayerCards()
        {
            // if the sum of the players cards is currently 0 it will take the value of the next card drawn and add it to the Players current sum value. 
            playerCardSum = 0;
            for (int i = 0; i < playerCardList.Count; i++)
            {
                playerCardSum += playerCardList[i].Value;
            }

            // if the players Cards is less then 21
            if(playerCardSum > 21)
            {
                // adding values for each value within the deck
                foreach(Card card in playerCardList)
                {
                    // if the cards value is 11. AKA Ace. 
                    if(card.Value == 11)
                    {
                        playerCardSum -= 10;

                        // If the players card is less then or equal to 21, end.
                        if(playerCardSum <= 21)
                        {
                            break;
                        }
                    }
                }
            }
        }

        // The sum of the Dealers Cards
        private void sumDealerCards()
        {
            // Start the Dealers Sum value at 0
            dealerCardSum = 0;

            // if the dealers card sum is = 0 and it is less then the dealers card list value, the value will increase.
            for (int i = 0; i < dealerCardList.Count; i++)
            { 
                // the dealer card sum will add onto the cardlist value of the dealer.
                dealerCardSum += dealerCardList[i].Value;
            }

            // If the dealers card sum is over 21
            if (dealerCardSum > 21)
            {
                foreach (Card card in dealerCardList)
                {
                    if (card.Value == 11)
                    {
                        dealerCardSum -= 10;
                        if (dealerCardSum <= 21)
                        {
                            break;
                        }
                    }
                }
            }
        }
        // Handing cards to Players
        private void DealButton_Click(object sender, EventArgs e)
        {
            // if the players card value is at 0 (which it will be everytime you start a game, it will prompt you to hit the start button.
            if (playerCardSum == 0)
            {
                resultLabel.Text = "Click the Deal button...";
               
            }
            // Otherwise if the players Sum is greater then 25, the game will be resetting
            else
            {
                if (playerCardSum > 25) 
                {
                    resetGame();
                    resultLabel.Text = "Resetting game...";
                }

                else
                {
                    playerCardSum = 0;
                    int randomCard = selectRandomCard();
                    Card card = deck[randomCard];
                    usedCards.Add(randomCard);

                    if (usedCards.Contains(randomCard)) randomCard = selectRandomCard();
                    else randomCard = 1 * randomCard;


                    // Adding a New Card
                    PictureBox p3 = new PictureBox();
                    p3.Width = 71;
                    p3.Height = 96;
                    p3.Location = new Point(154 + 77 + playerBox.Count * 77, 137 );
                    p3.ImageLocation = card.Image;
                    p3.SizeMode = PictureBoxSizeMode.AutoSize;
                    this.Controls.Add(p3);

                    playerBox.Add(p3);

                    playerCardList.Add(card);
                    sumPlayerCards();

                    // If the Players Card Sum is over 21
                    if (playerCardSum > 21)
                    {
                        // Display a formatted appropriate message
                        resultLabel.Text = String.Format
                            ("The sum of your cards is: {0}, you lose!", playerCardSum);
                        MessageBox.Show("You lose!", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        resetGame();
                    }
                    // if the players car is equal to 21
                    else if (playerCardSum == 21)
                    {
                        // display appropriate formatted message
                        resultLabel.Text = String.Format
                            ("The sum of your cards is: {0}, you win!", playerCardSum);
                        MessageBox.Show("You win!", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        resetGame();
                    }
                }
            }
        }
        // Resetting the Game
        private void resetButton_Click(object sender, EventArgs e)
        {
            resetGame();
        }

        private void resetGame()
        {
            // reset the fields
            resultLabel.Text = null;

            displayCardBack(pictureBox1);
            displayCardBack(pictureBox2);
            //displayCardBack(pictureBox3);
            displayCardBack(pictureBox4);
            //displayCardBack(pictureBox6);

            // remove any visible cards in the players Area
            foreach(PictureBox thisBox in playerBox)
            {
                this.Controls.Remove(thisBox);
            }
            // set a new picture box list
            playerBox = new List<PictureBox>();

            // remove any pictures in the Dealers Area
            foreach (PictureBox thisBox in dealerBox)
            {
                this.Controls.Remove(thisBox);
            }
            // set a new dealer box list
            dealerBox = new List<PictureBox>();

            // Reset the sums
            playerCardSum = 0;
            dealerCardSum = 0;

           //reset the lists
            playerCardList.Clear();
            dealerCardList.Clear();

            // Clear the used cards
            usedCards.Clear();

            // Set a final Lable
            resultLabel.Text = "Player Options.";
        }

        // Display the cards
        private void displayCardBack(PictureBox picturebox)
        {
            picturebox.ImageLocation = "b1fv.png";
            picturebox.SizeMode = PictureBoxSizeMode.AutoSize;
        }

        // Player Stop Button
        private void PlayerStopButton_Click(object sender, EventArgs e)
        {
            // Stop the game, set the lable to Prompt the user to hit the start button, then call the sumDealerCards method.
            if (playerCardSum == 0)
            {
                resultLabel.Text = "Click the Start button...";
                return;
            }
            sumDealerCards();

            // Dealers Move
            while (dealerCardSum <= 16)
            {
                // moves that the dealer will make while their card sum is less then or  = 16
                int randomCard = selectRandomCard();
                Card card = deck[randomCard];
                usedCards.Add(randomCard);

                // if the usedCards contain a RandomCard, then the randomCard will implement the selectRandomCard method
                if (usedCards.Contains(randomCard))
                {
                    randomCard = selectRandomCard();
                }

                else 
                {
                    randomCard = 1 * randomCard;
                }

                // Set the picture for the cards

                PictureBox p4 = new PictureBox();
                p4.Width = 71;
                p4.Height = 96;
                p4.Location = new Point(154 + dealerBox.Count * 77, 12);
                p4.ImageLocation = card.Image;
                p4.SizeMode = PictureBoxSizeMode.AutoSize;
                this.Controls.Add(p4);


                dealerBox.Add(p4);

                dealerCardList.Add(card);
                sumDealerCards();
            }

            // If the Dealers Card hand is over 21
            if (dealerCardSum > 21)
            {
                // Format appropriate lable
                resultLabel.Text = String.Format
                    ("The sum of banker cards is: {0}, you lose!", dealerCardSum);
                MessageBox.Show("You win!", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                resetGame();
            }
            // if the Player and Dealer card are equal
            else if (playerCardSum <= dealerCardSum)
            {
                // format appropriate message
                resultLabel.Text = String.Format
                    ("The sum of your cards is: {0}, you lose!", playerCardSum);
                MessageBox.Show("You lose!", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                resetGame();
            }
            else
            // otherwise if the players card is  higher then the dealer card.
            {
                // format appropriate message
                resultLabel.Text = String.Format
                    ("The sum of your cards is: {0}, you win!", playerCardSum);
                MessageBox.Show("You win!", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                resetGame();
            }

        }








        
    }
}
