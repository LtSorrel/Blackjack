﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blackjack
{
    class Card
    {
        // The card class is meant to hold information regarding each playing card, cards automatically get added to the list of a completed deck or each players cards
        public int Value { get; set; }
        public string Name { get; set; }
        public string Image { get; set; }
    }
}
